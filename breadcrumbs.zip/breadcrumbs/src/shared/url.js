/**
 * Normalizes a URL by removing query strings and trailing slashes.
 */
function normalizeUrl(url) {
    return url.split('?')[0].replace(/\/+$/, '');
}
