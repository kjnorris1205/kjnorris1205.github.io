// Alias for cross-browser compatibility
const browser = globalThis.browser || globalThis.chrome;

/**
 * Checks all links on the page and adds a class if it has been read
 */
function markReadPages() {
    // 1. Retrieve the list of read pages from storage
    browser.storage.local.get('readPages', (data) => {
        const pages = data.readPages || [];

        // 2. Find all link elements on the current webpage
        const links = document.querySelectorAll('a');

        links.forEach(link => {
            const url = normalizeUrl(link.href);

            // 3. Check if this link's URL is in our list of read pages
            if (pages.some(p => p.url === url)) {

                // 4. Mark the link as read
                link.classList.add('breadcrumbs-read-page')
            }
        });
    });
}

/**
 * Handles messages received from the background script
 */
function handleMessageReceived(request, sender, sendResponse) {
    if (request.action === 'mark-page-as-read') {
        const links = document.querySelectorAll('a');
        links.forEach(link => {
            const url = normalizeUrl(link.href);
            if (url === request.url) {
                link.classList.add('breadcrumbs-read-page');
            }
        });
        sendResponse({ status: "success" }); // Always respond
    } else if (request.action === 'mark-page-as-unread') {
        const links = document.querySelectorAll('a');
        links.forEach(link => {
            const url = normalizeUrl(link.href);
            if (url === request.url) {
                link.classList.remove('breadcrumbs-read-page');
            }
        });
        sendResponse({ status: "success" }); // Always respond
    }
    return false; // Return false since we are responding synchronously
}

/**
 * Normalizes a URL by removing query strings and trailing slashes.
 */
function normalizeUrl(url) {
    return url.split('?')[0].replace(/\/+$/, '');
}

// Register event handlers
browser.runtime.onMessage.addListener(handleMessageReceived);

// Execute the function to mark read pages
markReadPages();
