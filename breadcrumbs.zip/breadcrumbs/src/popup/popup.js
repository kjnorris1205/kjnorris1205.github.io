/**
 * Loads and displays pages from storage, split by status.
 */
async function loadPages() {
    const data = await browser.storage.local.get('savedPages');
    const pages = data.savedPages || [];

    const readList = document.getElementById('read-pages');
    const inProgressList = document.getElementById('in-progress-pages');
    readList.innerHTML = '';
    inProgressList.innerHTML = '';

    pages.toReversed().forEach(p => {
        const li = document.createElement('li');

        const title = document.createElement('span');
        title.className = 'title';
        title.textContent = p.title;

        const link = document.createElement('a');
        link.href = p.url;
        link.target = '_blank';
        link.textContent = p.url;
        link.title = p.title;

        const date = document.createElement('span');
        date.className = 'date';
        date.textContent = new Date(p.date).toLocaleString();

        li.append(title, link, date);

        if (p.status === 'in-progress') {
            inProgressList.appendChild(li);
        } else {
            readList.appendChild(li);
        }
    });
}

// Initialize when the popup opens
document.addEventListener('DOMContentLoaded', loadPages);

// Refresh the list when storage changes (e.g. context menu actions from the popup)
browser.storage.onChanged.addListener((changes, area) => {
    if (area === 'local' && changes.savedPages) {
        loadPages();
    }
});
