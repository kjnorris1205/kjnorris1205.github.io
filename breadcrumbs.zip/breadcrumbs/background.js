// Alias for cross-browser compatibility
const browser = globalThis.browser || globalThis.chrome;

/**
 * Creates the context menu items for the extension.
 */
function createContextMenus() {
    // Clear existing menus to prevent duplicate ID errors on reload
    browser.contextMenus.removeAll(() => {
        browser.contextMenus.create({
            id: 'mark-page-as-read',
            title: 'Mark Page as Read',
            contexts: ['page']
        });
        browser.contextMenus.create({
            id: 'mark-page-as-unread',
            title: 'Mark Page as Unread',
            contexts: ['page']
        });
        browser.contextMenus.create({
            id: 'mark-link-as-read',
            title: 'Mark Link as Read',
            contexts: ['link']
        });
        browser.contextMenus.create({
            id: 'mark-link-as-unread',
            title: 'Mark Link as Unread',
            contexts: ['link']
        });
    });
}

/**
 * Handles context menu item selections.
 */
function handleContextMenusClicked(info, tab) {
    const { menuItemId, pageUrl, linkUrl, linkText } = info;

    switch (menuItemId) {
        case 'mark-page-as-read':
            addReadPage({
                url: normalizeUrl(pageUrl),
                title: tab.title || '',
                date: new Date().toISOString()
            });
            browser.tabs.sendMessage(tab.id, {
                action: 'mark-page-as-read',
                url: normalizeUrl(pageUrl)
            });
            break;
        case 'mark-page-as-unread':
            removeReadPage({
                url: normalizeUrl(pageUrl),
            });
            browser.tabs.sendMessage(tab.id, {
                action: 'mark-page-as-unread',
                url: normalizeUrl(pageUrl)
            });
            break;
        case 'mark-link-as-read':
            addReadPage({
                url: normalizeUrl(linkUrl),
                title: linkText || '',
                date: new Date().toISOString()
            });
            browser.tabs.sendMessage(tab.id, {
                action: 'mark-page-as-read',
                url: normalizeUrl(linkUrl)
            });
            break;
        case 'mark-link-as-unread':
            removeReadPage({
                url: normalizeUrl(linkUrl),
            });
            browser.tabs.sendMessage(tab.id, {
                action: 'mark-page-as-unread',
                url: normalizeUrl(linkUrl)
            });
            break;
        default:
            console.warn('Unknown menu item clicked:', menuItemId);
    }
}

/**
 * Adds the page to the read pages list.
 */
function addReadPage(pageData) {
    browser.storage.local.get('readPages', (data) => {
        const readPages = data.readPages || [];

        // Make sure the read page doesn't already exist
        if (!readPages.some(p => p.url === pageData.url)) {
            readPages.push(pageData);
        }

        browser.storage.local.set({ readPages });
    });
}

/**
 * Removes the page from the read pages list.
 */
function removeReadPage(pageData) {
    browser.storage.local.get('readPages', (data) => {
        const readPages = data.readPages || [];

        // Filter out the read page
        const filteredReadPages = readPages.filter(p => p.url !== pageData.url);

        browser.storage.local.set({ readPages: filteredReadPages });
    });
}

// Listen for tab updates (like navigating to a new URL)
function handleBrowserTabUpdated(tabId, changeInfo, tab) {
    // Only trigger when the page is fully loaded and has a URL
    if (changeInfo.status === 'complete' && tab.url) {

        // 1. Get your options object
        const defaults = {
            options: { userName: "", autoBreadcrumbs: false }
        };

        browser.storage.local.get(defaults, (result) => {
            const options = result.options;

            // 2. Check if the user turned on the auto breadcrumbs feature
            if (options.autoBreadcrumbs) {
                console.log('Auto-breadcrumbs is ON. Saving link:', tab.url);

                // 3. Get existing breadcrumbs or start a new list
                browser.storage.local.get('breadcrumbs', data => {
                    const breadcrumbs = data.breadcrumbs || [];
                    
                    // 4. Add the new link to the list
                    breadcrumbs.push({
                        url: tab.url,
                        title: tab.title,
                        time: Date.now()
                    });

                    // 5. Save back to storage
                    browser.storage.local.set({ breadcrumbs });
                });
            }
        });
    }
};


/**
 * Normalizes a URL by removing query strings and trailing slashes.
 */
function normalizeUrl(url) {
    return url.split('?')[0].replace(/\/+$/, '');
}

// Register event handlers
browser.runtime.onInstalled.addListener(createContextMenus);
browser.contextMenus.onClicked.addListener(handleContextMenusClicked);
browser.tabs.onUpdated.addListener(handleBrowserTabUpdated);
