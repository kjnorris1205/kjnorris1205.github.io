# Breadcrumbs

A browser extension that helps you remember where you've been on the web. Mark pages as **read**, **in progress**, or **unread** and see visual indicators on links you've already visited.

## Features

- **Mark pages & links** via the right-click context menu — mark as Read, In Progress, or Unread
- **Visual indicators** on links across the web — a ✓ for read pages and ◑ for in-progress pages
- **Scroll position memory** — automatically saves and restores your scroll position on in-progress pages
- **Auto breadcrumbs** — optionally log every page you visit
- **SPA support** — detects client-side navigation and dynamically added links
- **Import / Export** — back up and restore your data as JSON
- **Cross-browser** — works on Chrome, Edge, and Firefox (via [webextension-polyfill](https://github.com/nicolo-ribaudo/webextension-polyfill))

## Installation

### Chrome / Edge (manual)

1. Clone or download this repository
2. Open `chrome://extensions` (or `edge://extensions`)
3. Enable **Developer mode**
4. Click **Load unpacked** and select the project folder

### Firefox (manual)

1. Open `about:debugging#/runtime/this-firefox`
2. Click **Load Temporary Add-on**
3. Select the `manifest.json` file in the project folder

## Usage

- **Right-click a page** to mark it as Read, In Progress, or Unread
- **Right-click a link** to mark the linked page without navigating to it
- Click the **Breadcrumbs icon** in the toolbar to see your saved pages
- Open **Options** (right-click the toolbar icon → Options) to configure auto-breadcrumbs, export/import data, and more

## Project Structure

```
manifest.json
lib/
  browser-polyfill.min.js   # webextension-polyfill
src/
  background/
    background.js            # Service worker: context menus, auto-breadcrumbs
  content/
    content.js               # Content script: link marking, scroll restore
    content.css              # Visual indicators for marked links
  options/
    options.html/js/css      # Options page
  popup/
    popup.html/js/css        # Toolbar popup
  shared/
    url.js                   # URL normalization utility
```

## License

MIT
