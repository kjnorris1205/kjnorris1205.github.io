// Alias for cross-browser compatibility
const browser = globalThis.browser || globalThis.chrome;

// Options elements
const userNameInput = document.getElementById('user-name');
const autoBreadcrumbsCheckbox = document.getElementById('auto-breadcrumbs');
const breadcrumbsList = document.getElementById('breadcrumbs-list');

// Other UI elements
const saveButton = document.getElementById('save');
const clearReadPagesButton = document.getElementById('clear-read-pages');
const clearBreadcrumbsButton = document.getElementById('clear-breadcrumbs');
const statusContainer = document.getElementById('status');

// Load options
function loadOptions() {
    const defaults = {
        options: { userName: "", autoBreadcrumbs: false }
    };

    browser.storage.local.get(defaults, (result) => {
        const options = result.options;

        userNameInput.value = options.userName;
        autoBreadcrumbsCheckbox.checked = options.autoBreadcrumbs;
    });
}

// Save options
function saveOptions() {
    const options = {
        userName: userNameInput.value,
        autoBreadcrumbs: autoBreadcrumbsCheckbox.checked
    };

    browser.storage.local.set({ options: options }, () => {
        statusContainer.textContent = "Options saved!";
        setTimeout(() => { statusContainer.textContent = ""; }, 2000);
    });
}

// Clear read pages
function clearReadPages() {
    browser.storage.local.remove('readPages', () => {
        statusContainer.textContent = "Read pages cleared!";
        setTimeout(() => { statusContainer.textContent = ""; }, 2000);
    });
}

// Clear breadcrumbs
function clearBreadcrumbs() {
    browser.storage.local.remove('breadcrumbs', () => {
        statusContainer.textContent = "Breadcrumbs cleared!";
        setTimeout(() => { statusContainer.textContent = ""; }, 2000);
        loadBreadcrumbs();
    });
}

/*
* Loads and displays the list of breadcrumbs
*/
function loadBreadcrumbs() {
    browser.storage.local.get('breadcrumbs', (data) => {
        const breadcrumbs = data.breadcrumbs || [];
        breadcrumbsList.innerHTML = '';

        breadcrumbs.toReversed().forEach((crumb) => {
            const li = document.createElement('li');

            // Securely set text content to prevent XSS
            const title = document.createElement('span');
            title.className = 'title'
            title.textContent = crumb.title;

            const link = document.createElement('a');
            link.href = crumb.url;
            link.target = '_blank';
            link.textContent = crumb.url
            
            const time = document.createElement('span');
            time.className = 'time';
            time.textContent = new Date(crumb.time).toLocaleString();

            li.append(title, link, time);
            breadcrumbsList.appendChild(li);
        });
    });
}

// Register event handlers
saveButton.addEventListener('click', saveOptions);
clearReadPagesButton.addEventListener('click', clearReadPages);
clearBreadcrumbsButton.addEventListener('click', clearBreadcrumbs);

// Run on load
loadOptions();
loadBreadcrumbs();
