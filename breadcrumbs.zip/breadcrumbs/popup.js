// Alias for cross-browser compatibility
const browser = globalThis.browser || globalThis.chrome;

/**
 * Loads and displays the list of read pages from storage.
 */
function loadReadPages() {
    browser.storage.local.get('readPages', (data) => {
        const pages = data.readPages || [];
        const list = document.getElementById('read-pages');
        list.innerHTML = ''; // Clear existing

        pages.toReversed().forEach(p => {
            const li = document.createElement('li');

            // Securely set text content to prevent XSS
            const title = document.createElement('span');
            title.className = 'title';
            title.textContent = p.title;

            const link = document.createElement('a');
            link.href = p.url;
            link.target = '_blank';
            link.textContent = p.url;
            link.title = p.title;

            const date = document.createElement('span');
            date.className = 'date';
            date.textContent = new Date(p.date).toLocaleString();

            li.append(title, link, date);
            list.appendChild(li);
        });
    });
}

// Initialize when the popup opens
document.addEventListener('DOMContentLoaded', loadReadPages);
