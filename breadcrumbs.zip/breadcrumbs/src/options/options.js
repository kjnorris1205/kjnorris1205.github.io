// Options elements
const userNameInput = document.getElementById('user-name');
const autoBreadcrumbsCheckbox = document.getElementById('auto-breadcrumbs');
const breadcrumbsList = document.getElementById('breadcrumbs-list');

// Other UI elements
const saveButton = document.getElementById('save');
const clearSavedPagesButton = document.getElementById('clear-saved-pages');
const clearBreadcrumbsButton = document.getElementById('clear-breadcrumbs');
const exportDbButton = document.getElementById('export-db');
const importDbButton = document.getElementById('import-db');
const importFileInput = document.getElementById('import-file');
const statusContainer = document.getElementById('status');

// Load options
async function loadOptions() {
    const defaults = {
        options: { userName: "", autoBreadcrumbs: false }
    };

    const results = await browser.storage.local.get(defaults);
    const options = results.options;

    userNameInput.value = options.userName;
    autoBreadcrumbsCheckbox.checked = options.autoBreadcrumbs;
}

// Save options
async function handleSaveButtonClicked() {
    const options = {
        userName: userNameInput.value,
        autoBreadcrumbs: autoBreadcrumbsCheckbox.checked
    };

    await browser.storage.local.set({ options: options });
    statusContainer.textContent = "Options saved!";
    setTimeout(() => { statusContainer.textContent = ""; }, 2000);
}

// Clear saved pages
async function clearSavedPages() {
    await browser.storage.local.remove('savedPages');
    statusContainer.textContent = "Saved pages cleared!";
    setTimeout(() => { statusContainer.textContent = ""; }, 2000);
}

// Clear breadcrumbs
async function clearBreadcrumbs() {
    await browser.storage.local.remove('breadcrumbs');
    statusContainer.textContent = "Breadcrumbs cleared!";
    setTimeout(() => { statusContainer.textContent = ""; }, 2000);
    await loadBreadcrumbs();  // Refresh the breadcrumbs list in the UI after clearing
}

/*
* Loads and displays the list of breadcrumbs
*/
async function loadBreadcrumbs() {
    const data = await browser.storage.local.get('breadcrumbs');
    const breadcrumbs = data.breadcrumbs || [];
    breadcrumbsList.innerHTML = '';

    breadcrumbs.toReversed().forEach((crumb) => {
        const li = document.createElement('li');

        // Securely set text content to prevent XSS
        const title = document.createElement('span');
        title.className = 'title'
        title.textContent = crumb.title;

        const link = document.createElement('a');
        link.href = crumb.url;
        link.target = '_blank';
        link.textContent = crumb.url
        
        const time = document.createElement('span');
        time.className = 'time';
        time.textContent = new Date(crumb.time).toLocaleString();

        li.append(title, link, time);
        breadcrumbsList.appendChild(li);
    });
}

// Register event handlers
saveButton.addEventListener('click', handleSaveButtonClicked);
clearSavedPagesButton.addEventListener('click', clearSavedPages);
clearBreadcrumbsButton.addEventListener('click', clearBreadcrumbs);
exportDbButton.addEventListener('click', exportDatabase);
importDbButton.addEventListener('click', () => importFileInput.click());
importFileInput.addEventListener('change', importDatabase);

// Run on load
loadOptions();
loadBreadcrumbs();

// Export database as JSON file
async function exportDatabase() {
    const data = await browser.storage.local.get(['savedPages', 'options', 'breadcrumbs']);

    const exportData = {
        version: '0.2',
        options: data.options || {},
        breadcrumbs: data.breadcrumbs || [],
        savedPages: data.savedPages || []
    };

    const blob = new Blob([JSON.stringify(exportData, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'breadcrumbs-export.json';
    a.click();
    URL.revokeObjectURL(url);
}

// Import database from JSON file with version handling
async function importDatabase(event) {
    const file = event.target.files[0];
    if (!file) return;

    const text = await file.text();
    let importData;
    try {
        importData = JSON.parse(text);
    } catch {
        statusContainer.textContent = 'Invalid JSON file.';
        setTimeout(() => { statusContainer.textContent = ''; }, 3000);
        importFileInput.value = '';
        return;
    }

    let savedPages;
    let options;
    let breadcrumbs;

    switch (importData.version) {
        case '0.1': {
            // v0.1: { version: "0.1", readPages: [{ url, title, date }] }
            const readPages = importData.readPages || [];
            savedPages = readPages.map(p => ({
                url: p.url,
                title: p.title,
                date: p.date,
                status: 'read'
            }));
            break;
        }
        case '0.2': {
            // v0.2: { version: "0.2", savedPages, options, breadcrumbs }
            savedPages = importData.savedPages || [];
            options = importData.options;
            breadcrumbs = importData.breadcrumbs;
            break;
        }
        default:
            statusContainer.textContent = `Unknown version: ${importData.version}`;
            setTimeout(() => { statusContainer.textContent = ''; }, 3000);
            importFileInput.value = '';
            return;
    }

    const storageUpdate = { savedPages };
    if (options) storageUpdate.options = options;
    if (breadcrumbs) storageUpdate.breadcrumbs = breadcrumbs;

    await browser.storage.local.set(storageUpdate);

    statusContainer.textContent = `Imported ${savedPages.length} pages (from v${importData.version}).`;
    setTimeout(() => { statusContainer.textContent = ''; }, 3000);
    importFileInput.value = '';

    // Refresh the UI to reflect imported data
    loadOptions();
    loadBreadcrumbs();
}
