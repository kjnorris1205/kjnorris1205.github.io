importScripts('../../lib/browser-polyfill.min.js', '../shared/url.js');

/**
 * Creates the context menu items for the extension.
 */
async function createContextMenus() {
    // Clear existing menus to prevent duplicate ID errors on reload
    await browser.contextMenus.removeAll();
   
    browser.contextMenus.create({
        id: 'mark-page-as-read',
        title: 'Mark Page as Read',
        contexts: ['page']
    });
    browser.contextMenus.create({
        id: 'mark-page-in-progress',
        title: 'Mark Page as In Progress',
        contexts: ['page']
    });
    browser.contextMenus.create({
        id: 'mark-page-as-unread',
        title: 'Mark Page as Unread',
        contexts: ['page']
    });
    browser.contextMenus.create({
        id: 'mark-link-as-read',
        title: 'Mark Link as Read',
        contexts: ['link']
    });
    browser.contextMenus.create({
        id: 'mark-link-in-progress',
        title: 'Mark Link as In Progress',
        contexts: ['link']
    });
    browser.contextMenus.create({
        id: 'mark-link-as-unread',
        title: 'Mark Link as Unread',
        contexts: ['link']
    });
}

/**
 * Safely sends a message to a tab's content script.
 * Silently skips if the tab ID is invalid (e.g. chrome:// pages).
 */
function safeSendMessage(tabId, message) {
    if (tabId >= 0) {
        browser.tabs.sendMessage(tabId, message).catch(() => {});
    }
}

/**
 * Returns the real page URL, falling back to the active tab's URL
 * when the context menu was triggered from an extension page (e.g. the popup).
 */
function resolvePageUrl(infoPageUrl, tabUrl) {
    if (/^(chrome|moz)-extension:\/\//.test(infoPageUrl)) {
        return tabUrl;
    }
    return infoPageUrl;
}

/**
 * Handles context menu item selections.
 */
async function handleContextMenusClicked(info, tab) {
    const { menuItemId, linkUrl, linkText } = info;
    const pageUrl = resolvePageUrl(info.pageUrl, tab.url);

    switch (menuItemId) {
        case 'mark-page-as-read':
            await savePage({
                url: normalizeUrl(pageUrl),
                title: tab.title || '',
                date: new Date().toISOString(),
                status: 'read'
            });
            safeSendMessage(tab.id, {
                action: 'update-page-status',
                url: normalizeUrl(pageUrl),
                status: 'read'
            });
            break;
        case 'mark-page-in-progress': {
            let scrollPosition = { elementSelector: null, scrollTop: 0 };
            try {
                scrollPosition = await browser.tabs.sendMessage(tab.id, { action: 'get-scroll-position' });
            } catch {}
            await savePage({
                url: normalizeUrl(pageUrl),
                title: tab.title || '',
                date: new Date().toISOString(),
                status: 'in-progress',
                scrollPosition
            });
            safeSendMessage(tab.id, {
                action: 'update-page-status',
                url: normalizeUrl(pageUrl),
                status: 'in-progress'
            });
            break;
        }
        case 'mark-page-as-unread':
            await removePage(normalizeUrl(pageUrl));
            safeSendMessage(tab.id, {
                action: 'update-page-status',
                url: normalizeUrl(pageUrl),
                status: 'unread'
            });
            break;
        case 'mark-link-as-read':
            await savePage({
                url: normalizeUrl(linkUrl),
                title: linkText || '',
                date: new Date().toISOString(),
                status: 'read'
            });
            safeSendMessage(tab.id, {
                action: 'update-page-status',
                url: normalizeUrl(linkUrl),
                status: 'read'
            });
            break;
        case 'mark-link-in-progress':
            await savePage({
                url: normalizeUrl(linkUrl),
                title: linkText || '',
                date: new Date().toISOString(),
                status: 'in-progress'
            });
            safeSendMessage(tab.id, {
                action: 'update-page-status',
                url: normalizeUrl(linkUrl),
                status: 'in-progress'
            });
            break;
        case 'mark-link-as-unread':
            await removePage(normalizeUrl(linkUrl));
            safeSendMessage(tab.id, {
                action: 'update-page-status',
                url: normalizeUrl(linkUrl),
                status: 'unread'
            });
            break;
        default:
            console.warn('Unknown menu item clicked:', menuItemId);
    }
}

/**
 * Saves a page with the given status (read or in progress).
 * If the page already exists, updates its status.
 */
async function savePage(pageData) {
    const data = await browser.storage.local.get('savedPages');
    const pages = data.savedPages || [];

    const index = pages.findIndex(p => p.url === pageData.url);
    if (index !== -1) {
        pages[index] = pageData;
    } else {
        pages.push(pageData);
    }

    await browser.storage.local.set({ savedPages: pages });
}

/**
 * Removes a page from the database (marks it as unread).
 */
async function removePage(url) {
    const data = await browser.storage.local.get('savedPages');
    const pages = data.savedPages || [];

    const filtered = pages.filter(p => p.url !== url);

    await browser.storage.local.set({ savedPages: filtered });
}

// Listen for tab updates (like navigating to a new URL)
// This is where we can implement the auto-breadcrumbs feature
async function handleBrowserTabUpdated(tabId, changeInfo, tab) {

    // When the URL changes (e.g. SPA navigation), tell the content script to re-scan links
    if (changeInfo.url) {
        browser.tabs.sendMessage(tabId, { action: 'url-changed' }).catch(() => {
            // Content script may not be ready yet; ignore
        });
    }

    // Only trigger when the page is fully loaded and has a URL
    if (changeInfo.status === 'complete' && tab.url) {

        // 1. Get your options object
        const defaults = {
            options: { userName: "", autoBreadcrumbs: false }
        };

        const result = await browser.storage.local.get(defaults);
        const options = result.options;

        // 2. Check if the user turned on the auto breadcrumbs feature
        if (options.autoBreadcrumbs) {
            console.log('Auto-breadcrumbs is ON. Saving link:', tab.url);

            // 3. Get existing breadcrumbs or start a new list
            const data = await browser.storage.local.get('breadcrumbs');
            const breadcrumbs = data.breadcrumbs || [];
                
            // 4. Add the new link to the list
            breadcrumbs.push({
                url: tab.url,
                title: tab.title,
                time: Date.now()
            });

            // 5. Save back to storage
            await browser.storage.local.set({ breadcrumbs });
        }
    }
};

// Register event handlers
browser.runtime.onInstalled.addListener(createContextMenus);
browser.contextMenus.onClicked.addListener(handleContextMenusClicked);
browser.tabs.onUpdated.addListener(handleBrowserTabUpdated);
