/**
 * Generates a CSS selector that uniquely identifies an element.
 */
function generateSelector(el) {
    if (el === document.documentElement) return 'html';
    if (el === document.body) return 'body';
    if (el.id) return '#' + CSS.escape(el.id);

    const parts = [];
    let current = el;
    while (current && current !== document.documentElement) {
        let selector = current.tagName.toLowerCase();
        if (current.id) {
            parts.unshift('#' + CSS.escape(current.id));
            break;
        }
        const parent = current.parentElement;
        if (parent) {
            const siblings = Array.from(parent.children).filter(c => c.tagName === current.tagName);
            if (siblings.length > 1) {
                const index = siblings.indexOf(current) + 1;
                selector += `:nth-of-type(${index})`;
            }
        }
        parts.unshift(selector);
        current = current.parentElement;
    }
    return parts.join(' > ');
}

/**
 * Finds the current scroll position by identifying the scrolled element.
 */
function getScrollPosition() {
    if (window.scrollY > 0 || document.documentElement.scrollTop > 0) {
        return {
            elementSelector: null,
            scrollTop: window.scrollY || document.documentElement.scrollTop
        };
    }

    const scroller = Array.from(document.querySelectorAll('*'))
        .find(el => el.scrollTop > 0);

    if (scroller) {
        return {
            elementSelector: generateSelector(scroller),
            scrollTop: scroller.scrollTop
        };
    }

    return { elementSelector: null, scrollTop: 0 };
}

/**
 * Restores scroll position for the current page if it's marked as in progress.
 */
async function restoreScrollPosition() {
    let data;
    try {
        data = await browser.storage.local.get('savedPages');
    } catch {
        return;
    }
    const pages = data.savedPages || [];
    const currentUrl = normalizeUrl(location.href);
    const page = pages.find(p => p.url === currentUrl && p.status === 'in-progress');

    if (!page?.scrollPosition || page.scrollPosition.scrollTop === 0) return;

    const { elementSelector, scrollTop } = page.scrollPosition;

    function applyScroll() {
        if (elementSelector) {
            const el = document.querySelector(elementSelector);
            if (el) {
                el.scrollTo({ top: scrollTop, behavior: 'smooth' });
                return true;
            }
            return false;
        } else {
            window.scrollTo({ top: scrollTop, behavior: 'smooth' });
            return true;
        }
    }

    // Try immediately
    if (applyScroll()) return;

    // If the element isn't ready yet, watch for DOM changes
    let attempts = 0;
    const observer = new MutationObserver(() => {
        attempts++;
        if (applyScroll() || attempts > 50) {
            observer.disconnect();
        }
    });
    observer.observe(document.body, { childList: true, subtree: true });

    // Safety timeout to stop observing
    setTimeout(() => observer.disconnect(), 10000);
}

/**
 * Checks all links on the page and adds a class if it has been read.
 * Can optionally accept a subset of link elements to check (for efficiency).
 */
async function markReadPages(linksToCheck) {
    // 1. Retrieve the list of pages from storage
    let data;
    try {
        data = await browser.storage.local.get('savedPages');
    } catch {
        // Extension context was invalidated (e.g. extension reloaded); stop gracefully
        return;
    }
    const pages = data.savedPages || [];

    // 2. Find all link elements on the current webpage (or use the provided subset)
    const links = linksToCheck || document.querySelectorAll('a');

    links.forEach(link => {
        const url = normalizeUrl(link.href);
        const page = pages.find(p => p.url === url);

        if (page?.status === 'read') {
            link.classList.add('breadcrumbs-read-page');
            link.classList.remove('breadcrumbs-in-progress-page');
        } else if (page?.status === 'in-progress') {
            link.classList.add('breadcrumbs-in-progress-page');
            link.classList.remove('breadcrumbs-read-page');
        }
    });
}

/**
 * Handles messages received from the background script
 */
function handleMessageReceived(request, sender, sendResponse) {
    if (request.action === 'update-page-status') {
        const links = document.querySelectorAll('a');
        links.forEach(link => {
            const url = normalizeUrl(link.href);
            if (url === request.url) {
                link.classList.remove('breadcrumbs-read-page', 'breadcrumbs-in-progress-page');
                if (request.status === 'read') {
                    link.classList.add('breadcrumbs-read-page');
                } else if (request.status === 'in-progress') {
                    link.classList.add('breadcrumbs-in-progress-page');
                }
            }
        });
        sendResponse({ status: "success" });
    } else if (request.action === 'url-changed') {
        // The background script detected a URL change (e.g. SPA navigation).
        // Re-scan all links on the page.
        markReadPages();
        sendResponse({ status: "success" });
    } else if (request.action === 'get-scroll-position') {
        sendResponse(getScrollPosition());
    }
    return false; // Return false since we are responding synchronously
}

/**
 * Watches for new links added to the DOM by client-side routers
 * and marks them if they've been read.
 */
function observeDomChanges() {
    let debounceTimer = null;

    const observer = new MutationObserver((mutations) => {
        // Collect any new <a> elements from added nodes
        const newLinks = [];
        for (const mutation of mutations) {
            for (const node of mutation.addedNodes) {
                if (node.nodeType !== Node.ELEMENT_NODE) continue;
                if (node.tagName === 'A') newLinks.push(node);
                // Also check descendants of added containers
                const nested = node.querySelectorAll?.('a');
                if (nested) newLinks.push(...nested);
            }
        }
        if (newLinks.length === 0) return;

        // Debounce so we batch rapid DOM updates (common during route transitions)
        clearTimeout(debounceTimer);
        debounceTimer = setTimeout(() => markReadPages(newLinks), 100);
    });

    observer.observe(document.body, { childList: true, subtree: true });
}

/**
 * Listens for client-side navigation events (pushState, replaceState, popstate)
 * so we can re-scan links after a route change.
 */
function observeUrlChanges() {
    let lastUrl = location.href;

    function onUrlChange() {
        const currentUrl = location.href;
        if (currentUrl !== lastUrl) {
            lastUrl = currentUrl;
            // Re-scan all links after a short delay to let the router render
            setTimeout(() => markReadPages(), 150);
        }
    }

    // Intercept history.pushState and history.replaceState
    const originalPushState = history.pushState;
    history.pushState = function (...args) {
        originalPushState.apply(this, args);
        onUrlChange();
    };

    const originalReplaceState = history.replaceState;
    history.replaceState = function (...args) {
        originalReplaceState.apply(this, args);
        onUrlChange();
    };

    // Back/forward button navigation
    window.addEventListener('popstate', onUrlChange);
}

// Register event handlers
browser.runtime.onMessage.addListener(handleMessageReceived);

// Execute the function to mark read pages
markReadPages();

// Restore scroll position if this is an in-progress page
restoreScrollPosition();

// Start watching for SPA changes
observeDomChanges();
observeUrlChanges();
